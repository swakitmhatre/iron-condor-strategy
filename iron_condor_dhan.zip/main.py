# Main strategy runner
print('Iron Condor strategy started...')